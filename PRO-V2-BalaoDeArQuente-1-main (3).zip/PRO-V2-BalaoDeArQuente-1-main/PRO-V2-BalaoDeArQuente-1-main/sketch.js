var bg, bgImg;
var bottomGround;
var topGround;
var balloon, balloonImg;
var obstaculo;
var obsBalao, obsPassaro;

function preload(){
bgImg = loadImage("assets/bg.png")

balloonImg = loadAnimation("assets/balloon1.png","assets/balloon2.png","assets/balloon3.png")

obsBalao = loadImage("assets/obsTop1.png");
obsPassaro = loadImage("assets/obsTop2.png");
}

function setup(){
 bg = createSprite(165,485,1,1);
 bg.addImage(bgImg);
 bg.scale = 1.3;

 bottomGround = createSprite(200,390,800,20);
 bottomGround.visible = false;
 topGround = createSprite(200,10,800,20);
 topGround.visible = false;

 balloon = createSprite(100,200,20,50);
 balloon.addAnimation("balloon", balloonImg);
 balloon.scale = 0.3;

}

function draw() {
  
  background("black");
 
  if(keyDown("space")){
    balloon.velocityY =-6;
  }

  balloon.velocityY = balloon.velocityY + 1;
  obstaculos();
  bar();
        drawSprites();
        
}

function obstaculos(){
  if(frameCount % 50 === 0){
   obstaculo = createSprite(400,50,40,50);
   obstaculo.velocityX = -4;
   obstaculo.scale = 0.1;
   obstaculo.y = Math.round(random(10,100));
   
   var obsImagem = Math.round(random(1,2));
   switch(obsImagem){
    case 1:
      obstaculo.addImage(obsBalao);
      break;
    case 2:
      obstaculo.addImage(obsPassaro);
      break;
    default:break;
   }

   obstaculo.lifetime = 400/4;
   balloon.depth += 1;

  }
}
  function bar(){
    if(frameCount % 50 === 0){
    var barra = createSprite(400,200,10,800);
    barra.velocityX = -6;
    barra.lifetime = 70;
    barra.visible = true;
    barra.depth = balloon.depth;
    } 
  }